// Get modal elements
var modal = document.getElementById('modal');
var modalImg = document.getElementById("modalImage");

// Get all gallery items
var images = document.getElementsByClassName('gallery-item');

// Loop through gallery images and add click event
for (let i = 0; i < images.length; i++) {
    images[i].onclick = function() {
        modal.style.display = "block";
        modalImg.src = this.src;
        document.body.classList.add('modal-open');
    }
}

// Close modal when clicking the 'X' (close button)
var span = document.getElementsByClassName("close")[0];
span.onclick = function() { 
    modal.style.display = "none";
    document.body.classList.remove('modal-open');
}
